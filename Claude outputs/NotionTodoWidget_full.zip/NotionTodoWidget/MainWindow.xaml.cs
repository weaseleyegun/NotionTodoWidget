using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;

namespace NotionTodoWidget;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<TodoItem> _items = new();
    private readonly DispatcherTimer _timer = new();
    private readonly DispatcherTimer _undoTimer = new() { Interval = TimeSpan.FromSeconds(6) };
    private readonly AppSettings _settings = AppSettings.Load();
    private readonly WidgetState _state = WidgetState.Load();

    private NotionClient? _client;
    private bool _ready;
    private bool _allExpanded;
    private int _pending;                 // 진행 중인 쓰기 작업 수 (자동 새로고침과 충돌 방지)
    private bool _dbInfoLoaded;
    private bool _firstLoadDone;          // 첫 불러오기 전에는 '할 일 없음' 안내를 숨김
    private string? _dbUrl;
    private Func<Task>? _undo;

    private enum Conn { NoToken, Syncing, Connected, Failed }

    public MainWindow()
    {
        InitializeComponent();
        TodoList.ItemsSource = _items;
        _items.CollectionChanged += (_, _) =>
        {
            CountText.Text = _items.Count.ToString();
            UpdateEmptyState();
        };
        _undoTimer.Tick += (_, _) => HideUndo();

        // 저장된 투명도 복원
        OpacitySlider.Value = _state.Opacity;
        ApplyOpacity(_state.Opacity);
        _ready = true;

        Closing += (_, _) => SaveState();

        if (string.IsNullOrWhiteSpace(_settings.NotionToken) || string.IsNullOrWhiteSpace(_settings.DatabaseId))
        {
            var why = string.IsNullOrWhiteSpace(_settings.NotionToken) ? "NotionToken 이 비어 있습니다." : "DatabaseId 가 비어 있습니다.";
            var detail = $"{why}\n읽은 파일: {_settings.LoadedFrom}";
            if (!string.IsNullOrEmpty(_settings.LoadError)) detail += $"\n파싱 오류: {_settings.LoadError}";
            ShowStatus(detail);
            SetConn(Conn.NoToken, detail);
            return;
        }

        _client = new NotionClient(_settings.NotionToken, _settings.DatabaseId);
        _timer.Interval = TimeSpan.FromSeconds(Math.Max(15, _settings.RefreshSeconds));
        _timer.Tick += async (_, _) => await RefreshAsync(auto: true);
    }

    // =====================================================================
    //  창 동작 (바탕화면 위젯처럼)
    // =====================================================================

    [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] private static extern int GetWindowLong(IntPtr hWnd, int index);
    [DllImport("user32.dll")] private static extern int SetWindowLong(IntPtr hWnd, int index, int value);

    private static readonly IntPtr HWND_BOTTOM = new(1);
    private const uint SWP_NOSIZE = 0x0001, SWP_NOMOVE = 0x0002, SWP_NOACTIVATE = 0x0010;
    private const int GWL_EXSTYLE = -20, WS_EX_TOOLWINDOW = 0x00000080;

    private void Window_SourceInitialized(object? sender, EventArgs e)
    {
        // Alt+Tab 목록에서 숨김
        var hwnd = new WindowInteropHelper(this).Handle;
        SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_TOOLWINDOW);
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        var area = SystemParameters.WorkArea;

        // 저장된 크기 복원
        if (_state.Width is double w) Width = Math.Clamp(w, MinWidth, area.Width);
        Height = Math.Clamp(_state.Height ?? Height, MinHeight, area.Height - 20);

        // 저장된 위치가 화면 안이면 복원, 아니면 오른쪽 위
        double vl = SystemParameters.VirtualScreenLeft, vt = SystemParameters.VirtualScreenTop;
        double vw = SystemParameters.VirtualScreenWidth, vh = SystemParameters.VirtualScreenHeight;
        if (_state.Left is double l && _state.Top is double t &&
            l > vl - 50 && l < vl + vw - 50 && t >= vt && t < vt + vh - 50)
        {
            Left = l;
            Top = t;
        }
        else
        {
            Left = area.Right - Width - 20;
            Top = area.Top + 20;
        }

        ApplyPin();
        UpdateEmptyState();

        if (_client is null) return;
        await RefreshAsync();
        _timer.Start();
    }

    private void Window_Activated(object? sender, EventArgs e) => SendToBottom();

    private void SendToBottom()
    {
        if (_state.Pinned) return;   // 고정 상태에서는 맨 뒤로 보내지 않음
        var hwnd = new WindowInteropHelper(this).Handle;
        SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }

    private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

    // ---------- 크기 조절 ----------

    private void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
        var area = SystemParameters.WorkArea;
        Width = Math.Clamp(Width + e.HorizontalChange, MinWidth, area.Width);
        Height = Math.Clamp(Height + e.VerticalChange, MinHeight, area.Height);
    }

    private void ResizeThumb_DragCompleted(object sender, DragCompletedEventArgs e) => SaveState();

    // ---------- 항상 위 고정 ----------

    private void Pin_Click(object sender, RoutedEventArgs e)
    {
        _state.Pinned = !_state.Pinned;
        ApplyPin();
        SaveState();
    }

    private void ApplyPin()
    {
        Topmost = _state.Pinned;
        PinButton.Content = _state.Pinned ? "" : "";
        PinButton.ToolTip = _state.Pinned ? "고정 해제 (바탕화면에 두기)" : "항상 위에 고정";
        PinButton.Foreground = _state.Pinned
            ? MakeBrush("#2383E2", 1.0)
            : MakeBrush("#787774", 1.0);
        if (!_state.Pinned) SendToBottom();
    }

    // ---------- Windows 시작 시 자동 실행 ----------

    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string RunValueName = "NotionTodoWidget";

    private static bool IsAutoStartEnabled()
    {
        using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath);
        return key?.GetValue(RunValueName) is string;
    }

    private void AutoStart_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, writable: true);
            if (key is null) return;

            if (AutoStartMenu.IsChecked && Environment.ProcessPath is { } exe)
                key.SetValue(RunValueName, $"\"{exe}\"");
            else
                key.DeleteValue(RunValueName, throwOnMissingValue: false);
        }
        catch (Exception ex)
        {
            ShowStatus("자동 실행 설정 실패: " + ex.Message);
        }
        AutoStartMenu.IsChecked = IsAutoStartEnabled();
    }

    protected override void OnContextMenuOpening(ContextMenuEventArgs e)
    {
        AutoStartMenu.IsChecked = IsAutoStartEnabled();
        base.OnContextMenuOpening(e);
    }

    // =====================================================================
    //  투명도
    // =====================================================================

    private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        _state.Opacity = e.NewValue;
        ApplyOpacity(e.NewValue);
    }

    private void OpacitySlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e) => SaveState();

    /// <summary>배경(패널·카드)만 투명하게 하고 글자는 그대로 선명하게 둡니다.</summary>
    private void ApplyOpacity(double value)
    {
        value = Math.Clamp(value, 0.3, 1.0);
        Resources["PanelBrush"] = MakeBrush("#F7F6F3", value);
        Resources["CardBrush"] = MakeBrush("#FFFFFF", Math.Min(1.0, value + 0.04));
        Resources["CardHoverBrush"] = MakeBrush("#FBFBFA", Math.Min(1.0, value + 0.04));
    }

    private static SolidColorBrush MakeBrush(string hex, double opacity)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)) { Opacity = opacity };
        brush.Freeze();
        return brush;
    }

    private void SaveState()
    {
        _state.Left = Left;
        _state.Top = Top;
        _state.Width = Width;
        _state.Height = Height;
        _state.Save();
    }

    // =====================================================================
    //  연결 상태
    // =====================================================================

    private void SetConn(Conn conn, string? detail = null)
    {
        string color, label;
        switch (conn)
        {
            case Conn.Connected:
                color = "#4ADE80";
                label = $"Notion 연결됨 · {DateTime.Now:HH:mm} 동기화";
                break;
            case Conn.Syncing:
                color = "#FBBF24";
                label = "Notion 동기화 중…";
                break;
            case Conn.Failed:
                color = "#F87171";
                label = "Notion 연결 실패";
                break;
            default:
                color = "#94A3B8";
                label = "Notion 토큰 없음";
                break;
        }

        StatusDot.Foreground = MakeBrush(color, 1.0);
        StatusLabel.Text = label;
        StatusPill.ToolTip = detail;
    }

    // =====================================================================
    //  데이터 불러오기
    // =====================================================================

    private bool IsUserTyping() => IsActive && Keyboard.FocusedElement is TextBox;

    private async Task RefreshAsync(bool auto = false)
    {
        if (_client is null) return;

        // 자동 새로고침은 쓰기 작업 중이거나 입력 중이면 건너뜁니다 (입력 내용 보호)
        if (auto && (_pending > 0 || IsUserTyping())) return;

        if (!auto) SetConn(Conn.Syncing);
        try
        {
            var fresh = await _client.GetOpenTodosAsync();

            bool same = fresh.Count == _items.Count &&
                        fresh.Zip(_items, (a, b) =>
                            a.Id == b.Id && a.Title == b.Title && a.Detail == b.Detail &&
                            a.DueText == b.DueText && a.IconPrefix == b.IconPrefix).All(x => x);

            if (!same)
            {
                var expanded = _items.Where(i => i.IsExpanded).Select(i => i.Id).ToHashSet();
                _items.Clear();
                foreach (var item in fresh)
                {
                    item.IsExpanded = expanded.Contains(item.Id);
                    _items.Add(item);
                }
            }

            _firstLoadDone = true;
            UpdateEmptyState();
            SetConn(Conn.Connected);
            HideStatus();

            if (!_dbInfoLoaded) await LoadDatabaseInfoAsync();
        }
        catch (Exception ex)
        {
            SetConn(Conn.Failed, ex.Message);
            ShowStatus("불러오기 실패: " + ex.Message);
        }
    }

    /// <summary>DB 제목과 URL 을 노션에서 가져옵니다 (하드코딩 없음).</summary>
    private async Task LoadDatabaseInfoAsync()
    {
        if (_client is null) return;
        try
        {
            var info = await _client.GetDatabaseInfoAsync();
            _dbUrl = info.Url;
            if (!string.IsNullOrWhiteSpace(info.Title)) HeaderTitle.Text = info.Title;
            _dbInfoLoaded = true;
        }
        catch (Exception)
        {
            // 다음 새로고침 때 다시 시도합니다.
        }
    }

    private void UpdateEmptyState()
    {
        EmptyText.Visibility = _items.Count == 0 && _client is not null && _firstLoadDone
            ? Visibility.Visible
            : Visibility.Collapsed;
    }

    // =====================================================================
    //  노션 열기
    // =====================================================================

    private async void OpenDatabase_Click(object sender, RoutedEventArgs e)
    {
        if (!_dbInfoLoaded) await LoadDatabaseInfoAsync();
        var url = _dbUrl ?? "https://www.notion.so/" + _settings.DatabaseId.Replace("-", "");
        OpenUrl(url);
    }

    private void OpenNotion_Click(object sender, RoutedEventArgs e)
    {
        if (GetItem(sender) is { } item && !string.IsNullOrEmpty(item.Url))
            OpenUrl(item.Url);
    }

    /// <summary>설정에 따라 노션 앱(notion://)으로 열고, 실패하면 브라우저로 엽니다.</summary>
    private void OpenUrl(string url)
    {
        try
        {
            if (_settings.OpenInNotionApp && url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    Process.Start(new ProcessStartInfo("notion://" + url.Substring("https://".Length)) { UseShellExecute = true });
                    return;
                }
                catch (Exception)
                {
                    // 노션 앱이 없으면 아래에서 브라우저로 엽니다.
                }
            }
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ShowStatus("열기 실패: " + ex.Message);
        }
    }

    // =====================================================================
    //  카드 이벤트
    // =====================================================================

    private static TodoItem? GetItem(object sender)
    {
        if (sender is FrameworkElement { DataContext: TodoItem a }) return a;
        if (sender is MenuItem { Parent: ContextMenu { PlacementTarget: FrameworkElement { DataContext: TodoItem b } } }) return b;
        return null;
    }

    private static bool IsInside<T>(DependencyObject? d) where T : DependencyObject
    {
        while (d is not null)
        {
            if (d is T) return true;
            d = d is Visual || d is System.Windows.Media.Media3D.Visual3D
                ? VisualTreeHelper.GetParent(d)
                : LogicalTreeHelper.GetParent(d);
        }
        return false;
    }

    private void Card_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        // 편집창 안을 클릭한 경우에는 접지 않습니다.
        if (e.OriginalSource is DependencyObject src && IsInside<TextBox>(src)) return;
        if (GetItem(sender) is { } item) item.IsExpanded = !item.IsExpanded;
    }

    private void Expand_Click(object sender, RoutedEventArgs e)
    {
        if (GetItem(sender) is { } item) item.IsExpanded = !item.IsExpanded;
    }

    private void CardToggle_Click(object sender, RoutedEventArgs e)
    {
        if (GetItem(sender) is { } item) item.IsExpanded = !item.IsExpanded;
    }

    private void ExpandAll_Click(object sender, RoutedEventArgs e)
    {
        _allExpanded = !_allExpanded;
        foreach (var item in _items) item.IsExpanded = _allExpanded;
        ExpandAllBtn.Content = _allExpanded ? "" : "";
        ExpandAllBtn.ToolTip = _allExpanded ? "모두 접기" : "모두 펼치기";
    }

    // ---------- 완료 (실행 취소 가능) ----------

    private async void Done_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not CheckBox { DataContext: TodoItem item } || _client is null) return;

        int index = _items.IndexOf(item);
        _items.Remove(item);   // 먼저 화면에서 치워서 반응을 빠르게

        _pending++;
        try
        {
            await _client.SetDoneAsync(item.Id, true);
            ShowUndo($"완료: {Shorten(item.Title)}", async () =>
            {
                await _client.SetDoneAsync(item.Id, false);
                await RefreshAsync();
            });
        }
        catch (Exception ex)
        {
            ShowStatus("완료 처리 실패: " + ex.Message);
            _items.Insert(Math.Min(index, _items.Count), item);   // 실패하면 되돌림
        }
        finally
        {
            _pending--;
        }
    }

    // ---------- 삭제 (노션 휴지통, 실행 취소 가능) ----------

    private async void CardDelete_Click(object sender, RoutedEventArgs e)
    {
        if (GetItem(sender) is not { } item || _client is null) return;

        int index = _items.IndexOf(item);
        _items.Remove(item);

        _pending++;
        try
        {
            await _client.SetArchivedAsync(item.Id, true);
            ShowUndo($"삭제: {Shorten(item.Title)}", async () =>
            {
                await _client.SetArchivedAsync(item.Id, false);
                await RefreshAsync();
            });
        }
        catch (Exception ex)
        {
            ShowStatus("삭제 실패: " + ex.Message);
            _items.Insert(Math.Min(index, _items.Count), item);
        }
        finally
        {
            _pending--;
        }
    }

    // ---------- 세부내용 편집 ----------

    private async void DetailEditor_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is not TextBox { DataContext: TodoItem item } box || _client is null) return;

        var text = box.Text.TrimEnd();
        if (text == item.Detail) return;

        var old = item.Detail;
        item.Detail = text;   // 화면에는 바로 반영

        _pending++;
        try
        {
            await _client.SetDetailAsync(item.Id, text);
        }
        catch (Exception ex)
        {
            item.Detail = old;
            ShowStatus("세부내용 저장 실패: " + ex.Message);
        }
        finally
        {
            _pending--;
        }
    }

    private void DetailEditor_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (sender is not TextBox { DataContext: TodoItem item } box) return;

        if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.Control)
        {
            e.Handled = true;
            AddBox.Focus();            // 포커스를 옮기면 LostFocus 에서 저장됩니다.
        }
        else if (e.Key == Key.Escape)
        {
            e.Handled = true;
            box.Text = item.Detail;    // 편집 취소
            AddBox.Focus();
        }
    }

    // =====================================================================
    //  새 할 일 추가 (제목 + 세부내용 + 마감일)
    // =====================================================================

    private void ToggleDetail_Click(object sender, RoutedEventArgs e)
    {
        bool show = NewDetailPanel.Visibility != Visibility.Visible;
        NewDetailPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        ToggleDetailBtn.Content = show ? "" : "";
        if (show) NewDetailBox.Focus();
    }

    private void ClearDue_Click(object sender, RoutedEventArgs e) => NewDuePicker.SelectedDate = null;

    private async void AddBox_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            await AddNewAsync();
        }
        else if (e.Key == Key.Escape)
        {
            e.Handled = true;
            if (AddBox.Text.Length > 0) AddBox.Clear();
            else if (NewDetailPanel.Visibility == Visibility.Visible) ToggleDetail_Click(sender, e);
        }
    }

    private async void NewDetailBox_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.Control)
        {
            e.Handled = true;
            await AddNewAsync();
        }
        else if (e.Key == Key.Escape)
        {
            e.Handled = true;
            AddBox.Focus();
        }
    }

    private async Task AddNewAsync()
    {
        if (_client is null) return;

        var title = AddBox.Text.Trim();
        if (title.Length == 0)
        {
            AddBox.Focus();
            return;
        }

        var detail = NewDetailBox.Text.Trim();
        DateTime? due = NewDuePicker.SelectedDate;

        _pending++;
        try
        {
            AddBox.IsEnabled = false;
            NewDetailBox.IsEnabled = false;

            await _client.AddAsync(title, detail, due);

            AddBox.Clear();
            NewDetailBox.Clear();
            NewDuePicker.SelectedDate = null;
            HideStatus();
        }
        catch (Exception ex)
        {
            ShowStatus("추가 실패: " + ex.Message);
            return;
        }
        finally
        {
            _pending--;
            AddBox.IsEnabled = true;
            NewDetailBox.IsEnabled = true;
            AddBox.Focus();
        }

        await RefreshAsync();
        if (due is null)   // 마감일 없는 항목은 맨 아래에 추가됨
            Dispatcher.BeginInvoke(new Action(() => ListScroll.ScrollToEnd()), DispatcherPriority.Loaded);
    }

    // =====================================================================
    //  실행 취소 / 메시지
    // =====================================================================

    private void ShowUndo(string text, Func<Task> undo)
    {
        _undo = undo;
        UndoText.Text = text;
        UndoBar.Visibility = Visibility.Visible;
        _undoTimer.Stop();
        _undoTimer.Start();
    }

    private void HideUndo()
    {
        _undoTimer.Stop();
        UndoBar.Visibility = Visibility.Collapsed;
        _undo = null;
    }

    private async void Undo_Click(object sender, RoutedEventArgs e)
    {
        var undo = _undo;
        HideUndo();
        if (undo is null) return;

        _pending++;
        try
        {
            await undo();
        }
        catch (Exception ex)
        {
            ShowStatus("실행 취소 실패: " + ex.Message);
        }
        finally
        {
            _pending--;
        }
    }

    private static string Shorten(string s, int max = 16)
        => s.Length <= max ? s : s.Substring(0, max) + "…";

    private void ShowStatus(string text)
    {
        StatusText.Text = text;
        StatusText.Visibility = Visibility.Visible;
    }

    private void HideStatus() => StatusText.Visibility = Visibility.Collapsed;
}
