using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace NotionTodoWidget;

public class AppSettings
{
    public string NotionToken { get; set; } = "";
    public string DatabaseId { get; set; } = "";
    public int RefreshSeconds { get; set; } = 60;

    /// <summary>true 면 notion:// 로 노션 데스크톱 앱에서 열고, 실패하면 브라우저로 엽니다.</summary>
    public bool OpenInNotionApp { get; set; } = true;

    /// <summary>실제로 읽은 설정 파일 경로 (문제 진단용)</summary>
    [JsonIgnore] public string LoadedFrom { get; private set; } = "";

    /// <summary>JSON 파싱 오류가 있었다면 그 내용</summary>
    [JsonIgnore] public string LoadError { get; private set; } = "";

    /// <summary>
    /// 실행 파일 폴더 → 상위 폴더(프로젝트 루트) → 현재 폴더 순으로 appsettings.json 을 찾고,
    /// NotionToken 이 채워진 첫 번째 파일을 사용합니다.
    /// </summary>
    public static AppSettings Load()
    {
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true
        };

        AppSettings? firstFound = null;
        string error = "";

        foreach (var path in Candidates())
        {
            try
            {
                var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(path), options);
                if (s is null) continue;

                s.LoadedFrom = path;
                firstFound ??= s;
                if (!string.IsNullOrWhiteSpace(s.NotionToken)) return s;
            }
            catch (Exception ex)
            {
                error = $"{path}: {ex.Message}";
            }
        }

        if (firstFound is not null) return firstFound;
        return new AppSettings { LoadedFrom = "(appsettings.json 을 찾지 못함)", LoadError = error };
    }

    private static IEnumerable<string> Candidates()
    {
        var dirs = new List<string>();
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (int i = 0; i < 6 && dir is not null; i++, dir = dir.Parent)
            dirs.Add(dir.FullName);
        dirs.Add(Directory.GetCurrentDirectory());

        foreach (var d in dirs.Distinct())
        {
            var p = Path.Combine(d, "appsettings.json");
            if (File.Exists(p)) yield return p;
        }
    }
}
