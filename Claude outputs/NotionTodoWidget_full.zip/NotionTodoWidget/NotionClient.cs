using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace NotionTodoWidget;

/// <summary>DB 제목과 URL (노션 API 에서 조회 — 하드코딩 없음)</summary>
public sealed record DatabaseInfo(string Title, string Url);

/// <summary>Notion API 호출 담당. DB 속성: Name(title), Done(checkbox), Detail(rich_text), Due(date)</summary>
public sealed class NotionClient
{
    private readonly HttpClient _http = new() { BaseAddress = new Uri("https://api.notion.com/v1/") };
    private readonly string _databaseId;

    public NotionClient(string token, string databaseId)
    {
        _databaseId = databaseId;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        _http.DefaultRequestHeaders.Add("Notion-Version", "2022-06-28");
    }

    // ---------- 조회 ----------

    /// <summary>DB 의 제목과 URL 을 가져옵니다. (헤더 제목 / "노션에서 열기" 용)</summary>
    public async Task<DatabaseInfo> GetDatabaseInfoAsync()
    {
        using var res = await _http.GetAsync($"databases/{_databaseId}");
        var text = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) throw new HttpRequestException(Describe(res, text));

        using var doc = JsonDocument.Parse(text);
        var root = doc.RootElement;

        string title = "";
        if (root.TryGetProperty("title", out var t) && t.ValueKind == JsonValueKind.Array)
        {
            title = string.Concat(t.EnumerateArray()
                .Select(p => p.TryGetProperty("plain_text", out var pt) ? pt.GetString() ?? "" : ""));
        }

        string url = root.TryGetProperty("url", out var u) ? u.GetString() ?? "" : "";
        if (string.IsNullOrEmpty(url))
            url = "https://www.notion.so/" + _databaseId.Replace("-", "");

        return new DatabaseInfo(title, url);
    }

    /// <summary>미완료(Done=false) 항목을 가져옵니다. 마감 임박 순, 마감일 없는 항목은 맨 뒤.</summary>
    public async Task<List<TodoItem>> GetOpenTodosAsync()
    {
        var list = new List<TodoItem>();
        string? cursor = null;

        do
        {
            var body = new Dictionary<string, object>
            {
                ["filter"] = new { property = "Done", checkbox = new { equals = false } },
                ["sorts"] = new[] { new { timestamp = "created_time", direction = "ascending" } },
                ["page_size"] = 100
            };
            if (cursor is not null) body["start_cursor"] = cursor;

            using var res = await _http.PostAsync($"databases/{_databaseId}/query", ToJson(body));
            var text = await res.Content.ReadAsStringAsync();
            if (!res.IsSuccessStatusCode) throw new HttpRequestException(Describe(res, text));

            using var doc = JsonDocument.Parse(text);
            var root = doc.RootElement;

            foreach (var page in root.GetProperty("results").EnumerateArray())
                list.Add(ParsePage(page));

            cursor = root.TryGetProperty("has_more", out var hm) && hm.ValueKind == JsonValueKind.True &&
                     root.TryGetProperty("next_cursor", out var nc)
                ? nc.GetString()
                : null;
        } while (cursor is not null);

        return list.OrderBy(t => t.Due ?? DateTime.MaxValue).ToList();
    }

    private static TodoItem ParsePage(JsonElement page)
    {
        var props = page.GetProperty("properties");

        string created = "";
        if (page.TryGetProperty("created_time", out var ct) &&
            DateTimeOffset.TryParse(ct.GetString(), out var createdAt))
        {
            created = createdAt.ToLocalTime().ToString("MM.dd");
        }

        // 페이지 아이콘(이모지)
        string iconPrefix = "";
        if (page.TryGetProperty("icon", out var icon) && icon.ValueKind == JsonValueKind.Object &&
            icon.TryGetProperty("emoji", out var emoji))
        {
            iconPrefix = (emoji.GetString() ?? "") + "  ";
        }

        // 마감일(Due 속성) → 남은 일수 태그
        DateTime? due = null;
        string dueText = "", dueKind = "none";
        if (props.TryGetProperty("Due", out var dueProp) &&
            dueProp.TryGetProperty("date", out var dateObj) && dateObj.ValueKind == JsonValueKind.Object &&
            dateObj.TryGetProperty("start", out var start) &&
            DateTime.TryParse(start.GetString(), out var parsed))
        {
            due = parsed.Date;
            int diff = (parsed.Date - DateTime.Today).Days;
            if (diff > 0) { dueText = $"{diff}일 남음"; dueKind = "ok"; }
            else if (diff == 0) { dueText = "오늘까지!"; dueKind = "today"; }
            else { dueText = $"{-diff}일 지남"; dueKind = "over"; }
        }

        return new TodoItem
        {
            Id = page.GetProperty("id").GetString() ?? "",
            Url = page.GetProperty("url").GetString() ?? "",
            CreatedText = created,
            IconPrefix = iconPrefix,
            Due = due,
            DueText = dueText,
            DueKind = dueKind,
            Title = ReadText(props, "Name", "title"),
            Detail = ReadText(props, "Detail", "rich_text")
        };
    }

    // ---------- 변경 ----------

    public Task SetDoneAsync(string pageId, bool done)
        => PatchPageAsync(pageId, new { properties = new { Done = new { checkbox = done } } });

    public Task SetDetailAsync(string pageId, string detail)
        => PatchPageAsync(pageId, new { properties = new { Detail = new { rich_text = RichText(detail) } } });

    /// <summary>삭제 = 노션 휴지통으로 이동(archived). false 로 되돌리면 복구됩니다.</summary>
    public Task SetArchivedAsync(string pageId, bool archived)
        => PatchPageAsync(pageId, new { archived });

    public async Task AddAsync(string title, string? detail = null, DateTime? due = null)
    {
        var properties = new Dictionary<string, object>
        {
            ["Name"] = new { title = RichText(title) }
        };
        if (!string.IsNullOrWhiteSpace(detail))
            properties["Detail"] = new { rich_text = RichText(detail) };
        if (due is not null)
            properties["Due"] = new { date = new { start = due.Value.ToString("yyyy-MM-dd") } };

        var body = new
        {
            parent = new { database_id = _databaseId },
            properties
        };

        using var res = await _http.PostAsync("pages", ToJson(body));
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException(Describe(res, await res.Content.ReadAsStringAsync()));
    }

    private async Task PatchPageAsync(string pageId, object body)
    {
        using var req = new HttpRequestMessage(HttpMethod.Patch, $"pages/{pageId}") { Content = ToJson(body) };
        using var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException(Describe(res, await res.Content.ReadAsStringAsync()));
    }

    // ---------- 도우미 ----------

    /// <summary>노션 rich_text 는 조각당 2000자 제한이라 나눠서 보냅니다. 빈 문자열이면 빈 배열(= 내용 지우기).</summary>
    private static object[] RichText(string text)
    {
        if (string.IsNullOrEmpty(text)) return Array.Empty<object>();

        var parts = new List<object>();
        for (int i = 0; i < text.Length; i += 2000)
            parts.Add(new { text = new { content = text.Substring(i, Math.Min(2000, text.Length - i)) } });
        return parts.ToArray();
    }

    private static string ReadText(JsonElement props, string name, string kind)
    {
        if (!props.TryGetProperty(name, out var prop)) return "";
        if (!prop.TryGetProperty(kind, out var arr) || arr.ValueKind != JsonValueKind.Array) return "";

        var sb = new StringBuilder();
        foreach (var part in arr.EnumerateArray())
        {
            if (part.TryGetProperty("plain_text", out var t)) sb.Append(t.GetString());
        }
        return sb.ToString();
    }

    private static StringContent ToJson(object body)
        => new(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

    private static string Describe(HttpResponseMessage res, string body)
    {
        string message = body;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("message", out var m)) message = m.GetString() ?? body;
        }
        catch (JsonException) { /* 본문이 JSON이 아니면 그대로 사용 */ }
        return $"{(int)res.StatusCode} {message}";
    }
}
