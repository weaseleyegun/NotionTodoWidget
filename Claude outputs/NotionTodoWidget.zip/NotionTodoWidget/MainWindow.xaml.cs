using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;

namespace NotionTodoWidget;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<TodoItem> _items = new();
    private readonly DispatcherTimer _timer = new();
    private readonly AppSettings _settings = AppSettings.Load();
    private NotionClient? _client;

    public MainWindow()
    {
        InitializeComponent();
        TodoList.ItemsSource = _items;

        if (string.IsNullOrWhiteSpace(_settings.NotionToken) || string.IsNullOrWhiteSpace(_settings.DatabaseId))
        {
            ShowStatus("appsettings.json 에 NotionToken 을 입력한 뒤 다시 실행하세요.");
            return;
        }

        _client = new NotionClient(_settings.NotionToken, _settings.DatabaseId);
        _timer.Interval = TimeSpan.FromSeconds(Math.Max(15, _settings.RefreshSeconds));
        _timer.Tick += async (_, _) => await RefreshAsync();
    }

    // ---------- 창 동작 (바탕화면 위젯처럼) ----------

    [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] private static extern int GetWindowLong(IntPtr hWnd, int index);
    [DllImport("user32.dll")] private static extern int SetWindowLong(IntPtr hWnd, int index, int value);

    private static readonly IntPtr HWND_BOTTOM = new(1);
    private const uint SWP_NOSIZE = 0x0001, SWP_NOMOVE = 0x0002, SWP_NOACTIVATE = 0x0010;
    private const int GWL_EXSTYLE = -20, WS_EX_TOOLWINDOW = 0x00000080;

    private void Window_SourceInitialized(object? sender, EventArgs e)
    {
        // Alt+Tab 목록에서 숨김
        var hwnd = new WindowInteropHelper(this).Handle;
        SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_TOOLWINDOW);
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        // 기본 위치: 화면 오른쪽 위
        var area = SystemParameters.WorkArea;
        Left = area.Right - Width - 20;
        Top = area.Top + 20;
        Height = Math.Min(Height, area.Height - 40);

        SendToBottom();
        if (_client is null) return;
        await RefreshAsync();
        _timer.Start();
    }

    private void Window_Activated(object? sender, EventArgs e) => SendToBottom();

    private void SendToBottom()
    {
        var hwnd = new WindowInteropHelper(this).Handle;
        SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }

    private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

    // ---------- 데이터 ----------

    private async Task RefreshAsync()
    {
        if (_client is null) return;
        try
        {
            var fresh = await _client.GetOpenTodosAsync();

            bool same = fresh.Count == _items.Count &&
                        fresh.Zip(_items, (a, b) => a.Id == b.Id && a.Title == b.Title && a.Detail == b.Detail).All(x => x);

            if (!same)
            {
                var expanded = _items.Where(i => i.IsExpanded).Select(i => i.Id).ToHashSet();
                _items.Clear();
                foreach (var item in fresh)
                {
                    item.IsExpanded = expanded.Contains(item.Id);
                    _items.Add(item);
                }
            }

            if (_items.Count == 0) ShowStatus("할 일이 없습니다. 아래에서 추가해 보세요.");
            else HideStatus();
        }
        catch (Exception ex)
        {
            ShowStatus("불러오기 실패: " + ex.Message);
        }
    }

    // ---------- 카드 이벤트 ----------

    private void Card_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        // 체크박스·버튼 클릭은 해당 컨트롤이 이벤트를 처리하므로 여기까지 오지 않습니다.
        if (sender is FrameworkElement { DataContext: TodoItem item } && item.HasDetail)
            item.IsExpanded = !item.IsExpanded;
    }

    private async void Done_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not CheckBox { DataContext: TodoItem item } box || _client is null) return;
        try
        {
            await _client.SetDoneAsync(item.Id, true);
            _items.Remove(item);
            if (_items.Count == 0) ShowStatus("모두 완료했습니다 🎉");
        }
        catch (Exception ex)
        {
            box.IsChecked = false;
            ShowStatus("완료 처리 실패: " + ex.Message);
        }
    }

    private void OpenNotion_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: TodoItem item } && !string.IsNullOrEmpty(item.Url))
            Process.Start(new ProcessStartInfo(item.Url) { UseShellExecute = true });
    }

    // ---------- 빠른 추가 ----------

    private async void AddBox_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || _client is null) return;
        e.Handled = true;

        var title = AddBox.Text.Trim();
        if (title.Length == 0) return;

        try
        {
            AddBox.IsEnabled = false;
            await _client.AddAsync(title);
            AddBox.Clear();
            await RefreshAsync();
        }
        catch (Exception ex)
        {
            ShowStatus("추가 실패: " + ex.Message);
        }
        finally
        {
            AddBox.IsEnabled = true;
            AddBox.Focus();
        }
    }

    // ---------- 상태 표시 ----------

    private void ShowStatus(string text)
    {
        StatusText.Text = text;
        StatusText.Visibility = Visibility.Visible;
    }

    private void HideStatus() => StatusText.Visibility = Visibility.Collapsed;
}
