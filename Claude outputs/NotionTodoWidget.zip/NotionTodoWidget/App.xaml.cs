using System.Windows;

namespace NotionTodoWidget;

public partial class App : Application
{
}
