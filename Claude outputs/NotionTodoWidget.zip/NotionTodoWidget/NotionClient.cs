using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace NotionTodoWidget;

/// <summary>Notion API 호출 담당. DB 속성: Name(title), Done(checkbox), Detail(rich_text)</summary>
public sealed class NotionClient
{
    private readonly HttpClient _http = new() { BaseAddress = new Uri("https://api.notion.com/v1/") };
    private readonly string _databaseId;

    public NotionClient(string token, string databaseId)
    {
        _databaseId = databaseId;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        _http.DefaultRequestHeaders.Add("Notion-Version", "2022-06-28");
    }

    /// <summary>미완료(Done=false) 항목을 생성 순서대로 가져옵니다.</summary>
    public async Task<List<TodoItem>> GetOpenTodosAsync()
    {
        var body = new
        {
            filter = new { property = "Done", checkbox = new { equals = false } },
            sorts = new[] { new { timestamp = "created_time", direction = "ascending" } },
            page_size = 100
        };

        using var res = await _http.PostAsync($"databases/{_databaseId}/query", ToJson(body));
        var text = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) throw new HttpRequestException(Describe(res, text));

        using var doc = JsonDocument.Parse(text);
        var list = new List<TodoItem>();

        foreach (var page in doc.RootElement.GetProperty("results").EnumerateArray())
        {
            var props = page.GetProperty("properties");
            list.Add(new TodoItem
            {
                Id = page.GetProperty("id").GetString() ?? "",
                Url = page.GetProperty("url").GetString() ?? "",
                Title = ReadText(props, "Name", "title"),
                Detail = ReadText(props, "Detail", "rich_text")
            });
        }
        return list;
    }

    public async Task SetDoneAsync(string pageId, bool done)
    {
        var body = new { properties = new { Done = new { checkbox = done } } };
        using var req = new HttpRequestMessage(HttpMethod.Patch, $"pages/{pageId}") { Content = ToJson(body) };
        using var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException(Describe(res, await res.Content.ReadAsStringAsync()));
    }

    public async Task AddAsync(string title)
    {
        var body = new
        {
            parent = new { database_id = _databaseId },
            properties = new
            {
                Name = new { title = new[] { new { text = new { content = title } } } }
            }
        };
        using var res = await _http.PostAsync("pages", ToJson(body));
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException(Describe(res, await res.Content.ReadAsStringAsync()));
    }

    private static string ReadText(JsonElement props, string name, string kind)
    {
        if (!props.TryGetProperty(name, out var prop)) return "";
        if (!prop.TryGetProperty(kind, out var arr) || arr.ValueKind != JsonValueKind.Array) return "";

        var sb = new StringBuilder();
        foreach (var part in arr.EnumerateArray())
        {
            if (part.TryGetProperty("plain_text", out var t)) sb.Append(t.GetString());
        }
        return sb.ToString();
    }

    private static StringContent ToJson(object body)
        => new(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

    private static string Describe(HttpResponseMessage res, string body)
    {
        string message = body;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("message", out var m)) message = m.GetString() ?? body;
        }
        catch (JsonException) { /* 본문이 JSON이 아니면 그대로 사용 */ }
        return $"{(int)res.StatusCode} {message}";
    }
}
