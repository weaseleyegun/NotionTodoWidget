using System.Text.Json;

namespace NotionTodoWidget;

public class AppSettings
{
    public string NotionToken { get; set; } = "";
    public string DatabaseId { get; set; } = "";
    public int RefreshSeconds { get; set; } = 60;

    public static AppSettings Load()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        if (!File.Exists(path)) return new AppSettings();

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(path), options)
               ?? new AppSettings();
    }
}
