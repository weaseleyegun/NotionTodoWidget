using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text;
using System.Text.Json;

namespace NotionTodoWidget;

/// <summary>Notion API 호출 담당. DB 속성: Name(title), Done(checkbox), Detail(rich_text)</summary>
public sealed class NotionClient
{
    private readonly HttpClient _http = new() { BaseAddress = new Uri("https://api.notion.com/v1/") };
    private readonly string _databaseId;

    public NotionClient(string token, string databaseId)
    {
        _databaseId = databaseId;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        _http.DefaultRequestHeaders.Add("Notion-Version", "2022-06-28");
    }

    /// <summary>미완료(Done=false) 항목을 생성 순서대로 가져옵니다.</summary>
    public async Task<List<TodoItem>> GetOpenTodosAsync()
    {
        var body = new
        {
            filter = new { property = "Done", checkbox = new { equals = false } },
            sorts = new[] { new { timestamp = "created_time", direction = "ascending" } },
            page_size = 100
        };

        using var res = await _http.PostAsync($"databases/{_databaseId}/query", ToJson(body));
        var text = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) throw new HttpRequestException(Describe(res, text));

        using var doc = JsonDocument.Parse(text);
        var list = new List<TodoItem>();

        foreach (var page in doc.RootElement.GetProperty("results").EnumerateArray())
        {
            var props = page.GetProperty("properties");

            string created = "";
            if (page.TryGetProperty("created_time", out var ct) &&
                DateTimeOffset.TryParse(ct.GetString(), out var createdAt))
            {
                created = createdAt.ToLocalTime().ToString("MM.dd");
            }

            // 페이지 아이콘(이모지)
            string iconPrefix = "";
            if (page.TryGetProperty("icon", out var icon) && icon.ValueKind == JsonValueKind.Object &&
                icon.TryGetProperty("emoji", out var emoji))
            {
                iconPrefix = (emoji.GetString() ?? "") + "  ";
            }

            // 마감일(Due 속성) → 남은 일수 태그
            DateTime? due = null;
            string dueText = "", dueKind = "none";
            if (props.TryGetProperty("Due", out var dueProp) &&
                dueProp.TryGetProperty("date", out var dateObj) && dateObj.ValueKind == JsonValueKind.Object &&
                dateObj.TryGetProperty("start", out var start) &&
                DateTime.TryParse(start.GetString(), out var parsed))
            {
                due = parsed.Date;
                int diff = (parsed.Date - DateTime.Today).Days;
                if (diff > 0) { dueText = $"{diff}일 남음"; dueKind = "ok"; }
                else if (diff == 0) { dueText = "오늘까지!"; dueKind = "today"; }
                else { dueText = $"{-diff}일 지남"; dueKind = "over"; }
            }

            list.Add(new TodoItem
            {
                Id = page.GetProperty("id").GetString() ?? "",
                Url = page.GetProperty("url").GetString() ?? "",
                CreatedText = created,
                IconPrefix = iconPrefix,
                Due = due,
                DueText = dueText,
                DueKind = dueKind,
                Title = ReadText(props, "Name", "title"),
                Detail = ReadText(props, "Detail", "rich_text")
            });
        }

        // 마감 임박 순(마감일 없는 항목은 맨 뒤), 같으면 생성 순서 유지
        return list.OrderBy(t => t.Due ?? DateTime.MaxValue).ToList();
    }

    public async Task SetDoneAsync(string pageId, bool done)
    {
        var body = new { properties = new { Done = new { checkbox = done } } };
        using var req = new HttpRequestMessage(HttpMethod.Patch, $"pages/{pageId}") { Content = ToJson(body) };
        using var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException(Describe(res, await res.Content.ReadAsStringAsync()));
    }

    public async Task AddAsync(string title)
    {
        var body = new
        {
            parent = new { database_id = _databaseId },
            properties = new
            {
                Name = new { title = new[] { new { text = new { content = title } } } }
            }
        };
        using var res = await _http.PostAsync("pages", ToJson(body));
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException(Describe(res, await res.Content.ReadAsStringAsync()));
    }

    private static string ReadText(JsonElement props, string name, string kind)
    {
        if (!props.TryGetProperty(name, out var prop)) return "";
        if (!prop.TryGetProperty(kind, out var arr) || arr.ValueKind != JsonValueKind.Array) return "";

        var sb = new StringBuilder();
        foreach (var part in arr.EnumerateArray())
        {
            if (part.TryGetProperty("plain_text", out var t)) sb.Append(t.GetString());
        }
        return sb.ToString();
    }

    private static StringContent ToJson(object body)
        => new(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

    private static string Describe(HttpResponseMessage res, string body)
    {
        string message = body;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("message", out var m)) message = m.GetString() ?? body;
        }
        catch (JsonException) { /* 본문이 JSON이 아니면 그대로 사용 */ }
        return $"{(int)res.StatusCode} {message}";
    }
}
